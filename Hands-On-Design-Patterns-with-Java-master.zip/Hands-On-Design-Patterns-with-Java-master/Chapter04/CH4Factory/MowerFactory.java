package CH4Factory;

abstract class MowerFactory {

    public abstract Mower getMowerType(String mowerType);
}
