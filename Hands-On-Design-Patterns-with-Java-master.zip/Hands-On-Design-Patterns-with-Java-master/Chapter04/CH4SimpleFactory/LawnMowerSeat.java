package CH4SimpleFactory;

public abstract class LawnMowerSeat {

    public LawnMowerSeat() {

    }
}
