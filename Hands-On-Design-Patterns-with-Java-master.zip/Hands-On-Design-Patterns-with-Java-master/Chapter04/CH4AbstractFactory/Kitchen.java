package CH4AbstractFactory;

public interface Kitchen {
    public String getKitchen();
}
