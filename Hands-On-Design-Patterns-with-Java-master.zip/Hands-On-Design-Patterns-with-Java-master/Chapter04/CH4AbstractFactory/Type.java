package CH4AbstractFactory;

public interface Type {
    public String getType();
}
