package CH4AbstractFactory;

public interface Style {
    public String getStyle();
}
