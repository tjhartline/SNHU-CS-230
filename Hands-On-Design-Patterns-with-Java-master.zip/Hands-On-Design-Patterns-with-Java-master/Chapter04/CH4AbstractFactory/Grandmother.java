package CH4AbstractFactory;

abstract class Grandmother {

    // Constructor
    Grandmother() {
        System.out.println("Grandmother constructor executed.");
    }
}
