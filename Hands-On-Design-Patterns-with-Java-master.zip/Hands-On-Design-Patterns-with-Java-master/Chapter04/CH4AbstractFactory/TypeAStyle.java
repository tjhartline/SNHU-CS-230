package CH4AbstractFactory;

public class TypeAStyle implements Style {

    public String getStyle() {

        return "[Type A] Style:\t\tOff the Grid";
    }
}
