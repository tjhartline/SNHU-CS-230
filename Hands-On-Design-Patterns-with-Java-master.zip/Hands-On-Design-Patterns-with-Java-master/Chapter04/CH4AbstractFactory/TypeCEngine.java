package CH4AbstractFactory;

public class TypeCEngine implements Engine {

    public String getEngine() {

        return "[Type C] Engine:\tFord E-450";
    }
}