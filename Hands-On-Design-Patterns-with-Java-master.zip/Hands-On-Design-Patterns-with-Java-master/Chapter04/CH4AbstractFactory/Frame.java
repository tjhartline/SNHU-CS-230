package CH4AbstractFactory;

public interface Frame {
    public String getFrame();
}
