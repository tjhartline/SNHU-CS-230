package CH4AbstractFactory;

public class Mother extends Grandmother {

    // Constructor
    Mother() {
        System.out.println("Mother constructor executed.");
    }
}
