package CH4AbstractFactory;

public class TypeCKitchen implements Kitchen {

    public String getKitchen() {

        return "[Type C] Kitchen:\tFull";
    }
}