package CH4AbstractFactory;

public class TypeAFrame implements Frame {

    public String getFrame() {

        return "[Type A] Frame:\t\tBus";
    }
}
