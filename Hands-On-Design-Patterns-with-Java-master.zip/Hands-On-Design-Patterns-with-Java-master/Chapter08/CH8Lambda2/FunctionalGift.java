package CH8Lambda2;

public interface FunctionalGift {

    void abstractMethod(int number);

}
