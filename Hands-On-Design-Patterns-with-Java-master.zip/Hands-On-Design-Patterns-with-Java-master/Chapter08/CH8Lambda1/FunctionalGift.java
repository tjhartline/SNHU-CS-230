package CH8Lambda1;

public interface FunctionalGift {

    void abstractMethod(int number);

}
