package CH5Adapter;

public class Estate {

    // class variables
    public double length;
    public double width;

    // constructor
    public Estate(int length, int width) {
        this.length = length;
        this.width = width;
    }
}
