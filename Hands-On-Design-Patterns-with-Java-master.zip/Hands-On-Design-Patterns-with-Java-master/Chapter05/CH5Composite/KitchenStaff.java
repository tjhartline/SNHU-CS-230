package CH5Composite;

public interface KitchenStaff {

    public String getDetails();
}
