package CH5Proxy.MasterClasses;

public abstract class Weather {

    public abstract void whoAmI();
}
