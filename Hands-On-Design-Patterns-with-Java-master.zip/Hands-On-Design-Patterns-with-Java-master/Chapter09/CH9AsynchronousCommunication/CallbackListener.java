package CH9AsynchronousCommunication;

public interface CallbackListener {

    void processCallback();
}

