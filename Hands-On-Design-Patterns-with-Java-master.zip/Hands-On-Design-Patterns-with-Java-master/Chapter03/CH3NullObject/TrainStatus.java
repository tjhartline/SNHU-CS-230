package CH3NullObject;

public interface TrainStatus {

    public void activate();
    public void deactivate();
    public boolean isActivated();
}
