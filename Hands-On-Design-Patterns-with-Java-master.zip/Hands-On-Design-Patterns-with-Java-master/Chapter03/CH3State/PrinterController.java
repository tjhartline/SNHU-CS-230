package CH3State;

abstract class PrinterController {

    public abstract void pushPrint(Printer printJob);
}
