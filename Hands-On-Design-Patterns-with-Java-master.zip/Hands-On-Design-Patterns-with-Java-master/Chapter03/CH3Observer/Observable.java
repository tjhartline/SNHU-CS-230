package CH3Observer;

public class Observable {
}
