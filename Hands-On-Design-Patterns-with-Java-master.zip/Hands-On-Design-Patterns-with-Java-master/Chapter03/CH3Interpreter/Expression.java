package CH3Interpreter;

interface Expression {

    void interpret(Conversion orignalContent);

}
